<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jahr', 'Jahre', 'Jahren', 'Millionen', 'Prozent', 'Uhr', 'ab', 'aber', 'alle', 'als', 'am', 'an', 'auch', 'auf', 'aus', 'bei', 'beim', 'bereits', 'bis', 'da', 'damit', 'dann', 'das', 'dass', 'dem', 'den', 'der', 'des', 'die', 'diese', 'diesem', 'dieser', 'doch', 'drei', 'durch', 'ein', 'eine', 'einem', 'einen', 'einer', 'eines', 'er', 'ersten', 'es', 'etwa', 'fÃ¼r', 'gegen', 'gibt', 'habe', 'haben', 'hat', 'hatte', 'ich', 'ihr', 'ihre', 'ihrer', 'im', 'immer', 'in', 'ist', 'jetzt', 'kann', 'keine', 'man', 'mehr', 'mit', 'muss', 'nach', 'neue', 'neuen', 'nicht', 'noch', 'nun', 'nur', 'oder', 'ohne', 'sagte', 'schon', 'sei', 'sein', 'seine', 'seinen', 'seiner', 'seit', 'selbst', 'sich', 'sie', 'sind', 'so', 'soll', 'sondern', 'um', 'und', 'unter', 'vom', 'von', 'vor', 'war', 'waren', 'was', 'wenn', 'werden', 'wie', 'wieder', 'will', 'wir', 'wird', 'worden', 'wurde', 'wurden', 'zu', 'zum', 'zur', 'zwei', 'zwischen', );