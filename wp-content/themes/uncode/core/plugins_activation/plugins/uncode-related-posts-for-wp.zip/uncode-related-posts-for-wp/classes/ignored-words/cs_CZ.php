<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

return array( '', 'a', 'aby', 'aj', 'ale', 'anebo', 'ani', 'ano', 'asi', 'ba', 'bez', 'bude', 'budem', 'by', 'byl', 'byla', 'byli', 'bylo', 'co', 'com', 'cz', 'design', 'dnes', 'do', 'email', 'ho', 'i', 'jak', 'je', 'jeho', 'jej', 'jejich', 'jen', 'ji', 'jsem', 'jsi', 'jsme', 'jsou', 'jste', 'k', 'kam', 'kde', 'kdo', 'ke', 'kterou', 'ku', 'mezi', 'mi', 'mne', 'mnou', 'my', 'na', 'nad', 'ne', 'nebo', 'nejsou', 'net', 'ni', 'nic', 'o', 'od', 'ode', 'on', 'org', 'pak', 'po', 'pod', 'podle', 'pokud', 'pouze', 'pro', 'proto', 're', 's', 'se', 'si', 'sice', 'spol', 'strana', 'ta', 'tak', 'tamhle', 'tato', 'tedy', 'ten', 'tento', 'tipy', 'to', 'tohle', 'toho', 'tohoto', 'tom', 'tomto', 'tomuto', 'tu', 'tuto', 'ty', 'tyto', 'u', 'v', 've', 'vedle', 'vy', 'z', 'za', 'zda', 'zde',);